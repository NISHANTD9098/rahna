
<!DOCTYPE HTML>
<html lang="zxx">

<head>
	<title>RAHNA :- AAPKA GHAR</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content=""
	/>
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- Meta tag Keywords -->
	<!-- css file -->
	<link rel="stylesheet" href="css/style2.css" type="text/css" media="all" />
	<!-- Style-CSS -->
	<!-- //css file -->
	<!-- web-fonts -->
	<link href="//fonts.googleapis.com/css?family=Cuprum:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext,vietnamese"
	    rel="stylesheet">
	

</head>

<body>

	<h1>
		<span>B</span>ook
		<span>V</span>isit
		
	</h1>
	
	<div class="sub-main-w3">
		<form validate="true" action="#" method="post">
			<div class="form-group">
				<label for="exampleInputText">Name</label>
				<input type="text" class="form-control" name="name" id="exampleInputText" placeholder="Enter Name" required>
			</div>
			<div class="form-group">
				<label for="exampleInputEmail1">Email address</label>
				<input type="email" class="form-control" name="name" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
			</div>
			<div class="form-group">
				<label for="exampleMobile1">Mobile Number</label>
				<input type="mobile" class="form-control" name="name" id="exampleMobile1" placeholder="Mobile number" required>
			</div>
			<div class="form-group">
				<label for="exampleInputPassword1">place</label>
				<input maxlength="10" minlength="3" type="text" name="name" class="form-control" id="exampleInputPassword1" placeholder="location of visit"
				    required>
			</div>
			<div class="form-group">
				<label for="exampleConfirmPassword1">Date</label>
				<input type="Date" class="form-control" id="" name="name" placeholder="" required data-match=""
				    data-match-field="">
			</div>
			<div class="form-group">
				<label class="checkbox-inline">
					<input type="checkbox" value="true" required>I agree to the terms and conditions
					<br>
					<p>
					Visit charge is ₹50 which is refundable after booking room.</p>
					<p>maximum 2 people can visit.</p>
				</label>
			</div>
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</div>
	
	<div class="footer">
		<p>
		
		</p>
	</div>
	

	
	<script src="js/jquery-2.2.3.min1.js"></script>
	
	<script src="js/jquery-simple-validator.min2.js"></script>
	

</body>

</html>