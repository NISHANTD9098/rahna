<!DOCTYPE html>
<html>
<head>
	<title>Add Hostel</title>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<html>
  <head>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
  </head>
  <style>body#LoginForm{ background-image:url("https://hdwallsource.com/img/2014/9/blur-26347-27038-hd-wallpapers.jpg"); background-repeat:no-repeat; background-position:center; background-size:cover; padding:10px;}

.form-heading { color:#fff; font-size:23px;}
.panel h2{ color:#444444; font-size:18px; margin:0 0 8px 0;}
.panel p { color:#777777; font-size:14px; margin-bottom:30px; line-height:24px;}
.login-form .form-control {
  background: #f7f7f7 none repeat scroll 0 0;
  border: 1px solid #d4d4d4;
  border-radius: 4px;
  font-size: 14px;
  height: 50px;
  line-height: 50px;
}
.main-div {
  background: #ffffff none repeat scroll 0 0;
  border-radius: 2px;
  margin: 10px auto 30px;
  max-width: 38%;
  padding: 50px 70px 70px 71px;
}

.login-form .form-group {
  margin-bottom:10px;
}
.login-form{ text-align:center;}
.forgot a {
  color: #777777;
  font-size: 14px;
  text-decoration: underline;
}
.login-form  .btn.btn-primary {
  background: #f0ad4e none repeat scroll 0 0;
  border-color: #f0ad4e;
  color: #ffffff;
  font-size: 14px;
  width: 100%;
  height: 50px;
  line-height: 50px;
  padding: 0;
}
.forgot {
  text-align: left; margin-bottom:30px;
}
.botto-text {
  color: #ffffff;
  font-size: 14px;
  margin: auto;
}
.login-form .btn.btn-primary.reset {
  background: #ff9900 none repeat scroll 0 0;
}
.back { text-align: left; margin-top:10px;}
.back a {color: #444444; font-size: 13px;text-decoration: none;}
</style>
<body id="LoginForm">
<div class="container">
<h1 class="form-heading">login Form</h1>
<div class="login-form">
<div class="main-div">
    <div class="panel">
   <h2>Admin Login For Hostel ADD</h2>
  
   </div>
    <form  action="" method="post" enctype="multipart/form-data">

        <div class="form-group">


           <select name="id"  class="form-control">
  
  <option value="1">Piplani</option>
  <option value="2">Anand Nagar</option>
   <option value="3">Indrapuri</option>
   <option value="4">Mp Nafr</option>
 
  </select>

        </div>

        <div class="form-group">

            <input type="text" name="hostel_name" class="form-control" id="hostel_name" placeholder="Hoste_Name">

        </div>
        <div class="form-group">

            <input type="text" name="hostel_address" class="form-control" id="hostel_address" placeholder="Hostel_address">

        </div>
        <div class="form-group">

            <input type="text" name="mobile" class="form-control" id="mobile" placeholder="Contact Number">

        </div>
        <div class="form-group">
                 
                  Image OF Hostel <input type="file" id="event_photo" name="event_photo" required="" class="form-control" accept=".gif, .jpg, .jpeg, .png">
                </div>
       
       <input type="submit" name="submit" class="form-control" style="margin-top: 20px;">
    </form>
    </div>

</div></div></div>


</body>
</html>
<?php 
mysql_connect('localhost','root','');
mysql_select_db('my_db');
if (isset($_POST['submit'])) {

	echo $id=$_POST['id'];
	$hostel_name=$_POST['hostel_name'];
	$hostel_address=$_POST['hostel_address'];
	$mobile=$_POST['mobile'];
	
	$event_photo=$_FILES['event_photo']['name'];
	$event_photo_temp=$_FILES['event_photo']['tmp_name'];
	$r=rand(1000000,9999999);
	$event_photo=$r.'_'.$event_photo;
	$path="uploads";
	
move_uploaded_file($event_photo_temp,$path."/$event_photo");
	
	
 
echo $quer="INSERT INTO `user`(`id`, `hostel_name`, `hostel_address`, `mobile`, `event_photo`) VALUES ('$id','$hostel_name','$hostel_address','$mobile','$event_photo')";
  
if(mysql_query($quer)){

     
		echo "<script>alert('Successfully Complete');</script>";
		echo "<script>window.open('welcome.php','_self')</script>";
	}
	

}


 ?>