<!DOCTYPE html>
<html lang="en">
  <head>
    <title>RAHNA - Apka Ghar</title>
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/a.css">
  </head>
  <body>
    
   <!--?php include 'header.php';?-->
   <?php $page='about'; include 'head.php';?>
  <!-- END nav -->


  
  <div class="block-30 block-30-sm item" style="background-image: url('images/about us.jpg');" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row align-items-center">
        
      </div>
    </div>
  </div>

    
  

    <div class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-12">
            
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 mb-3">
            <h2>Enjoy a Luxury Experience</h2><br>
            <h3>Who We Are</h3>
            <p>At Rahna Hospitality, we have become one of the  leading  companies by following a fairly simple philosophy--offer a product of outstanding quality with equally outstanding values. The simplicity of that principle is backed up by a lot of hard work. We provides many services  such as Rooms provider, Food service and various other services.</p>
            <h3>Dedication</h3>
            
            <p>We approach each property with a total dedication to excellence, which is reflected by each employee on every level. Every potential property is carefully evaluated and take care by Rahna Hospitality through a method developed. We partner with architects, engineers, and contractors who share our passion for excellence.</p>
            <h3>Satisfaction</h3>
             
            <p>In our years of management experience, we have learned that customer satisfaction can be summed up in three words--details, details, details. We have achieved superior levels of customer satisfaction by paying attention to the finest details in everything we do. That's how we have developed exceptional levels of repeat business. We know what is important to both business and pleasure travelers, and we deliver it.</p>
            <h3>Thank you</h3>

          </div>
          <div class="col-md-6">
            <p></p>
            <p></p>
            <p></p>
          </div>
          <div class="col-md-6">
            <p></p>
            <p></p>
          </div>

        </div>
      </div>
    </div>

    

    
     <div class="container">
      <div class="row site-section">
        <div class="col-md-12">
          <div class="row mb-5">
            <div class="col-md-7 section-heading">
              <span class="subheading-sm">Services</span>
              <h2 class="heading">Facilities &amp; Services</h2>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-double-bed"></span></div>
            <div class="media-body">
              <h3 class="heading">Rooms</h3>
              <p>Here Rahna.in provide you best rooms with affordable price.</p>
            </div>
          </div>      
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-wifi"></span></div>
            <div class="media-body">
              <h3 class="heading">Best and near by locations</h3>
              <p>We select the location which is near by market and your desire place.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-customer-service"></span></div>
            <div class="media-body">
              <h3 class="heading">Call Us </h3>
              <p>We trust that our customers is our "King", so we all always ready for your service and help.</p>
            </div>
          </div>
        </div>
      

        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-taxi"></span></div>
            <div class="media-body">
              <h3 class="heading">Travel Accomodation</h3>
              <p>If you are from other town and want to stay in other town then we are here,we will provide accomodation service.</p>
            </div>
          </div>      
        </div>
        
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-dinner"></span></div>
            <div class="media-body">
              <h3 class="heading">Food</h3>
              <p>If you don't want to cook food at home then don't worry,We will provide your 3 time meal at affordable price .</p>
            </div>
          </div>
        </div>

      </div>
       </div>    <div class="site-section bg-light">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-7 section-heading">        
            <span class="subheading-sm">Reviews</span>
            <h2 class="heading">Guest Reviews</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4">

            <div class="block-33">
              <div class="vcard d-flex mb-3">
                <div class="image align-self-center"><img src="images/q.jpg" alt="Person here"></div>
                <div class="name-text align-self-center">
                  <h2 class="heading">Dheeraj Sharma,Oriental collage,bhopal</h2>
                  <span class="meta">Satisfied Customer</span>
                </div>
              </div>
              <div class="text">
                <blockquote>
                  <p>&rdquo; Good startup and good service,kam accha h. &ldquo;</p>
                </blockquote>
              </div>
            </div>

          </div>
          <div class="col-md-6 col-lg-4">

            <div class="block-33">
              <div class="vcard d-flex mb-3">
                <div class="image align-self-center"><img src="images/qw.jpg" alt="Person here"></div>
                <div class="name-text align-self-center">
                  <h2 class="heading">Riya Rai,LNCT Bhopal</h2>
                  <span class="meta">Satisfied Customer</span>
                </div>
              </div>
              <div class="text">
                <blockquote>
                  <p>&rdquo; Good people and good service,keep going. &ldquo;</p>
                </blockquote>
              </div>
            </div>

          </div>
          <div class="col-md-6 col-lg-4">

            <div class="block-33">
              <div class="vcard d-flex mb-3">
                <div class="image align-self-center"><img src="images/w.jpeg " alt="Person here"></div>
                <div class="name-text align-self-center">
                  <h2 class="heading">Satyam Mehra,NRI Collage Bhopal</h2>
                  <span class="meta">Satisfied Customer</span>
                </div>
              </div>
              <div class="text">
                <blockquote>
                  <p>&rdquo; Nice work,you make the whole process very easy, Thanks. &ldquo;</p>
                </blockquote>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>




   <?php include 'footer.php';?>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>