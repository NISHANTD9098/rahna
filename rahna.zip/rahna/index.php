<!DOCTYPE html>
<html lang="en">
  <head>
    <title>RAHNA- Apka Ghar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/a.css">
<style>
.button {
    background-color:#008CBA ; /* #4CAF50 Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}

.button2 {background-color:#008CBA ;} /* #008CBA Blue */
.button3 {background-color:#008CBA ;} /*  #f44336 Red */ 
.button4 {background-color:#008CBA ;} /*  #f44336Gray */ 
.button5 {background-color:#008CBA ;} /* #555555 Black */
 html,media-body{
  width: 100%;
  height: 100%;
  margin: 0px;
  padding: 0px;
  overflow-x: hidden;
 }
</style>  
  </head>

  <body>
    <?php $page='index';include 'head.php';?>
   <img src="images/Q1Q.jpg"  class="img-responsive" width="1500" height="500" style="width:100%;">
   <?php include 'aa.php';?>
   <div class="container">
      <div class="row site-section">
        <div class="col-md-12">
          <div class="row mb-5">
            <div class="col-md-7 section-heading">
              <span class="subheading-sm">Services</span>
              <h2 class="heading">Facilities &amp; Services</h2>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-double-bed"></span></div>
            <div class="media-body">
              <h3 class="heading">Rooms</h3>
              <p>Here Rahna.in provide you best rooms with affordable price.</p>
            </div>
          </div>      
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-wifi"></span></div>
            <div class="media-body">
              <h3 class="heading">Best and near by locations</h3>
              <p>We select the location which is near by market and your desire place.</p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-customer-service"></span></div>
            <div class="media-body">
              <h3 class="heading">Call Us </h3>
              <p>We trust that our customers is our "King", so we all always ready for your service and help.</p>
            </div>
          </div>
        </div>
      

        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-taxi"></span></div>
            <div class="media-body">
              <h3 class="heading">Travel Accomodation</h3>
              <p>If you are from other town and want to stay in other town then we are here,we will provide accomodation service.</p>
            </div>
          </div>      
        </div>
        
        <div class="col-md-6 col-lg-4">
          <div class="media block-6">
            <div class="icon"><span class="flaticon-dinner"></span></div>
            <div class="media-body">
              <h3 class="heading">Food</h3>
              <p>If you don't want to cook food at home then don't worry,We will provide your 3 time meal at affordable price .</p>
            </div>
          </div>
        </div>

      </div>
       </div>
       </div>
      </div>
      <div class="container">
       <span class="subheading-sm">Featured Rooms</span>
              <h2 class="heading">Rooms &amp; Suites</h2>
              <p>We are providing our service in MP Nagar,Indrapuri,Anand Nagar,We are working Hard to serve you at your place very soon!</p>
  <div class="row">
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/single.jpg" target="_blank">
          <img src="images/single.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <h2 class="heading">SINGLE ROOM</h2>
            <h3>₹4000 /-</h3>
                       
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/ROOM2.jpg" target="_blank">
          <img src="images/ROOM2.jpg" alt="Nature" style="width:100%">
          <div class="caption">
           <h2 class="heading">HOSTEL</h2>
            <h3>₹5000 /-</h3>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/ROOM3.jpg"target="_blank">
          <img src="images/ROOM3.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
            <h2 class="heading">PG-ROOMS</h2>
            <h3>₹6000 /-</h3>
          </div>
        </a>
      </div>
    </div>
  </div>
</div>

      <div class="site-section bg-light">
      <div class="container" >
        <div class="row mb-5">
            <div class="col-md-7 section-heading">
              <span class="subheading-sm">Food sevice</span>
              <h2 class="heading">Tifin</h2>
            </div>
          </div>

        <div class="block-35">
          
          <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
              <div class="row">
                
                <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/food1.jpg" target="_blank">
          <img src="images/food1.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <h2 class="heading">2 TIME MEAL</h2>
            <h3>₹2000 /-</h3>
            <h5>2 Time Meal include Lunch & Dinner</h5>
                       
          </div>
        </a>
      </div>
    </div>

    <div class="col-md-4">
      <div class="thumbnail">
        <a href="images/food2.jpg" target="_blank">
          <img src="images/food2.jpg" alt="Lights" style="width:100%">
          <div class="caption">
            <h2 class="heading">3 TIME MEAL</h2>
            <h3>₹2200 /-</h3>
            <h5>3 Time Meal include Breakfast,Lunch & Dinner</h5>
                       
          </div>
        </a>
      </div>
    </div>
              </div>
            </div>


           
           
          </div>

        </div>
      </div>
    </div>

    <div class="block-30 block-30-sm item" style="background-image: url('images/canteen.jpg');" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-md-12">
              <h2 class="heading">Quality accommodation that exceeds the expectations</h2>
              
            </div>
          </div>
        </div>
      </div>

    <div class="site-section bg-light">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-7 section-heading">        
            <span class="subheading-sm">Reviews</span>
            <h2 class="heading">Guest Reviews</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4">

            <div class="block-33">
              <div class="vcard d-flex mb-3">
                <div class="image align-self-center"><img src="images/q.jpg" alt="Person here"></div>
                <div class="name-text align-self-center">
                  <h2 class="heading">Dheeraj Sharma,Oriental collage,bhopal</h2>
                  <span class="meta">Satisfied Customer</span>
                </div>
              </div>
              <div class="text">
                <blockquote>
                  <p>&rdquo; Good startup and good service,kam accha h. &ldquo;</p>
                </blockquote>
              </div>
            </div>

          </div>
          <div class="col-md-6 col-lg-4">

            <div class="block-33">
              <div class="vcard d-flex mb-3">
                <div class="image align-self-center"><img src="images/qw.jpg" alt="Person here"></div>
                <div class="name-text align-self-center">
                  <h2 class="heading">Riya Rai,LNCT Bhopal</h2>
                  <span class="meta">Satisfied Customer</span>
                </div>
              </div>
              <div class="text">
                <blockquote>
                  <p>&rdquo; Good people and good service,keep going. &ldquo;</p>
                </blockquote>
              </div>
            </div>

          </div>
          <div class="col-md-6 col-lg-4">

            <div class="block-33">
              <div class="vcard d-flex mb-3">
                <div class="image align-self-center"><img src="images/w.jpeg " alt="Person here"></div>
                <div class="name-text align-self-center">
                  <h2 class="heading">Satyam Mehra,NRI Collage Bhopal</h2>
                  <span class="meta">Satisfied Customer</span>
                </div>
              </div>
              <div class="text">
                <blockquote>
                  <p>&rdquo; Nice work,you make the whole process very easy, Thanks. &ldquo;</p>
                </blockquote>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
    </div>
  
   <?php include 'footer.php';?>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>