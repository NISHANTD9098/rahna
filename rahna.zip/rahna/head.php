<style>
	.link-3:hover {
  background-color: blue;
  color: #EEA200;
  padding: 24px 10px;
}
</style>
<div class="header" >
	<a href="index" class="logo">Rahna.in</a>
  <div class="header-right">
    <a class="<?php if($page=='index'){echo 'active';} ?>" href="index">Home</a>
    <a class="<?php if($page=='about'){echo 'active';} ?>"href="about" >About Us</a>
    <a class="<?php if($page=='contact'){echo 'active';} ?>"href="Contact">Contact</a>
    <a href="#about">Call:-9098660803</a>
  </div>
</div> 