 
<button type="button" class="btn  btn-block" style="background-color: #008CBA;color: white">SELECT AREA</button>
<div style="margin-top: 10px;margin-bottom:20px">
<div class="row">
    
  <div class="col-sm-3"><a href="MpNagar.php"><button type="button" class="btn btn-info" style="color: black" href="rooms.php">MP NAGAR</button></a></div>
  <div class="col-sm-3"><a href="Piplani.php"><button type="button" class="btn btn-info"style="color: black">PIPLANI</button></a></div>
  <div class="col-sm-3"><a href="Indrapuri.php"><button type="button" class="btn btn-info"style="color: black">INDRAPURI</button></a></div><a href="rooms.php">
  <div class="col-sm-3"><a href="AnandNagar.php"><button type="button" class="btn btn-info"style="color: black">ANAND NAGAR</button> </a></div>
  </div>
</div>
</div>