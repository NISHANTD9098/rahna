<!DOCTYPE html>
<html>
<head>
<title>Insert Image in MySql using PHP</title>
</head>
<body>
<?php
mysql_connect('localhost','root','');
mysql_select_db('my_db');
if(isset($_POST['finish'])){ 

	$event_photo=$_FILES['event_photo']['name'];
	$event_photo_temp=$_FILES['event_photo']['tmp_name'];
	$r=rand(1000000,9999999);
	$event_photo=$r.'_'.$event_photo;
	$path="uploads";
	
move_uploaded_file($event_photo_temp,$path."/$event_photo");
	
	
  $quer="insert into user(event_photo)
    values('$event_photo')";

 
  
if(mysql_query($quer)){

     
		echo "<script>alert('Successfully Complete');</script>";
		echo "<script>window.open('welcome.php','_self')</script>";
	}
	

}
?>

<form method="post" enctype="multipart/form-data" action="">
			 
		<div class="box-body ">
		<center><h3  style="font-size: 30px;">List Of Image</h3></center>
		
			<div class="col-md-3 ">				
			 	<div class="form-group">
                  <label style="color: black; font-size: 30px;">File Uploads <font style="color:red;  font-size: 30px;"></font> </label>
                   <input type="file" id="event_photo" name="event_photo" required="" class="form-control" accept=".gif, .jpg, .jpeg, .png">
                </div>
			</div>
	       	
		</div>	
		
	
		<div class="col-md-12" style="padding: 50px;">
		      <input type="submit" name="finish" value="Submit" class="btn  my_background_color" />
		</div>
		
			</div>
			
	  </form>	

</body>
</html>