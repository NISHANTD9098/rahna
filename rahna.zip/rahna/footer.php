<footer class="footer" >
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-6 col-lg-4">
          <h3 class="heading-section">About Us</h3>
          <p class="mb-5">At Rahna Hospitality, we have become one of the  leading  companies by following a fairly simple philosophy--offer a product of outstanding quality with equally outstanding values. The simplicity of that principle is backed up by a lot of hard work. We provides many services  such as Rooms provider, Food service and various other services..</p>
          <p><a  class="btn btn-primary px-4">Go-Up</a></p>
        </div>
        <div class="col-md-6 col-lg-4">
          <h3 class="heading-section"></h3>
        </div>
        <div class="col-md-6 col-lg-4">
          <div class="block-23">
            <h3 class="heading-section">Contact Info</h3>
              <ul>
                <li><span class="icon icon-map-marker"></span><span class="text">B-67,Machna colony,shivaji nagar,bhopal</span></li>
                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+91 9098660803</span></a></li>
                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">info@rahna.com</span></a></li>
                <li><span class="icon icon-clock-o"></span><span class="text">Monday &mdash; Friday 8:00am - 5:00pm</span></li>
              </ul>
            </div>
        </div>
        
        
      </div>
      
    </div>
  </footer>